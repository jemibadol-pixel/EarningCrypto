# EarningCrypto Android Starter

This is a Flutter UI starter for the EarningCrypto Android app.

## Included
- English interface
- Home dashboard
- Tasks screen
- USDT wallet preview
- Referral screen
- Responsive Material 3 layout

## Important
This is a **UI starter**, not a live earning or payment app. Balances are demo-only. Login, database, ad network, verified tasks, referral attribution, admin tools, and real USDT deposits/withdrawals are not connected.

Do not accept deposits or promise earnings until the backend, fraud prevention, security, legal/compliance review, and payment operations are implemented.

## Build an Android APK
1. Install Flutter SDK and Android Studio on a computer.
2. Extract this ZIP.
3. Open a terminal in this folder and run:
   - `flutter pub get`
   - `flutter run` (test on a device/emulator)
   - `flutter build apk --release`
4. The release APK is usually created at `build/app/outputs/flutter-apk/app-release.apk`.

## Suggested next engineering step
Add authentication and a server-side database first. Keep balance updates on the server; never let the mobile app directly set its own USDT balance.
