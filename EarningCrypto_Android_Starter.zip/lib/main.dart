import 'package:flutter/material.dart';

void main() => runApp(const EarningCryptoApp());

const Color navy = Color(0xFF101827);
const Color panel = Color(0xFF1B2638);
const Color green = Color(0xFF31D49A);
const Color muted = Color(0xFF9AA8BA);

class EarningCryptoApp extends StatelessWidget {
  const EarningCryptoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EarningCrypto',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: green,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int selected = 0;

  final pages = const [
    DashboardPage(),
    TasksPage(),
    WalletPage(),
    ReferralPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy,
        title: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: green,
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(Icons.currency_bitcoin, color: navy),
            ),
            const SizedBox(width: 10),
            const Text('EarningCrypto', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () => _notice(context, 'Notifications will be connected in a later version.'),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: SafeArea(child: pages[selected]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF151F2F),
        indicatorColor: green.withOpacity(.16),
        selectedIndex: selected,
        onDestinationSelected: (i) => setState(() => selected = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.task_alt_rounded), label: 'Tasks'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.people_alt_outlined), label: 'Invite'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
      children: [
        const Text('Welcome back 👋', style: TextStyle(color: muted, fontSize: 15)),
        const SizedBox(height: 5),
        const Text('Your earning dashboard', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              colors: [Color(0xFF214C48), Color(0xFF19312F), Color(0xFF1B2638)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: green.withOpacity(.35)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.account_balance_wallet_outlined, color: green),
                  SizedBox(width: 8),
                  Text('TOTAL BALANCE', style: TextStyle(color: Colors.white70, letterSpacing: 1.2, fontSize: 12)),
                  Spacer(),
                  Icon(Icons.visibility_outlined, color: Colors.white70, size: 19),
                ],
              ),
              const SizedBox(height: 15),
              const Text('0.00 USDT', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('Demo balance · No real funds', style: TextStyle(color: Colors.white70, fontSize: 12)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: FilledButton.icon(
                    onPressed: () => _notice(context, 'Withdrawals will be enabled after secure backend and payment review are complete.'),
                    icon: const Icon(Icons.south_west_rounded),
                    label: const Text('Withdraw'),
                    style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: navy),
                  )),
                  const SizedBox(width: 10),
                  Expanded(child: OutlinedButton.icon(
                    onPressed: () => _notice(context, 'Deposit is not available in this starter version.'),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Deposit'),
                  )),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const SectionHeading(title: 'Quick actions'),
        const SizedBox(height: 12),
        Row(
          children: const [
            Expanded(child: QuickCard(icon: Icons.play_circle_outline, title: 'Earn by tasks', subtitle: 'Complete tasks')),
            SizedBox(width: 10),
            Expanded(child: QuickCard(icon: Icons.people_outline, title: 'Invite friends', subtitle: 'Referral rewards')),
          ],
        ),
        const SizedBox(height: 22),
        const SectionHeading(title: 'Today’s overview'),
        const SizedBox(height: 12),
        const Row(
          children: [
            Expanded(child: StatCard(label: 'Tasks completed', value: '0', icon: Icons.task_alt)),
            SizedBox(width: 10),
            Expanded(child: StatCard(label: 'Referral bonus', value: '0.00', icon: Icons.group_add_outlined)),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: panel,
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.info_outline, color: green),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Starter preview only. Rewards, ads, referrals and USDT withdrawals are not live yet. Never deposit money into this demo.',
                  style: TextStyle(color: muted, height: 1.45, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class TasksPage extends StatelessWidget {
  const TasksPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Earn Rewards', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Available earning activities will appear here.', style: TextStyle(color: muted)),
      const SizedBox(height: 18),
      const TaskTile(icon: Icons.calendar_month_outlined, title: 'Daily check-in', subtitle: 'Open the app each day', reward: 'Coming soon'),
      const TaskTile(icon: Icons.play_circle_outline, title: 'Watch sponsored ads', subtitle: 'Only verified ad views can qualify', reward: 'Coming soon'),
      const TaskTile(icon: Icons.checklist_rounded, title: 'Complete a task', subtitle: 'Follow task instructions to qualify', reward: 'Coming soon'),
    ],
  );
}

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('My Wallet', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Currency: USDT · Demo mode', style: TextStyle(color: muted)),
      const SizedBox(height: 18),
      const StatCard(label: 'Available balance', value: '0.00 USDT', icon: Icons.account_balance_wallet_outlined),
      const SizedBox(height: 14),
      const TaskTile(icon: Icons.history, title: 'Transaction history', subtitle: 'No transactions yet', reward: ''),
      const TaskTile(icon: Icons.lock_outline, title: 'Secure withdrawals', subtitle: 'Real withdrawals require server-side verification and admin approval.', reward: 'Not active'),
    ],
  );
}

class ReferralPage extends StatelessWidget {
  const ReferralPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Invite Friends', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('Invite friends with your personal referral link and earn eligible rewards when the referral system launches.', style: TextStyle(color: muted, height: 1.5)),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20)),
        child: const Column(
          children: [
            Icon(Icons.people_alt_rounded, color: green, size: 42),
            SizedBox(height: 12),
            Text('Referral program', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            SizedBox(height: 8),
            Text('Your referral link will be created after account registration is connected.', textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.4)),
          ],
        ),
      ),
    ],
  );
}

class SectionHeading extends StatelessWidget {
  final String title;
  const SectionHeading({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));
}

class QuickCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const QuickCard({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: green, size: 27),
      const SizedBox(height: 15),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      Text(subtitle, style: const TextStyle(color: muted, fontSize: 12)),
    ]),
  );
}

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: green),
      const SizedBox(height: 14),
      Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      Text(label, style: const TextStyle(color: muted, fontSize: 12)),
    ]),
  );
}

class TaskTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String reward;
  const TaskTile({super.key, required this.icon, required this.title, required this.subtitle, required this.reward});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)),
    child: Row(children: [
      Container(width: 44, height: 44, decoration: BoxDecoration(color: green.withOpacity(.12), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: green)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: muted, fontSize: 12, height: 1.3)),
      ])),
      if (reward.isNotEmpty) ...[
        const SizedBox(width: 8),
        Text(reward, style: const TextStyle(color: green, fontSize: 11, fontWeight: FontWeight.w700)),
      ],
    ]),
  );
}

void _notice(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
  );
}
